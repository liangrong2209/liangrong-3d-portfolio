window.PORTFOLIO_DATA = {
  profile: {
    name: "梁容",
    title: "3D 创意设计｜潮玩 / 手办与实物制作",
    school: "北京大学（医学部）｜公共卫生 硕士在读｜2027 毕业",
    location: "北京",
    recruitment: "2027 届校园招聘｜3D 设计方向",
    slogan: "设计驱动型 · 实物落地产出者 · 全流程独立完成",
    summary:
      "北京大学公共卫生硕士在读，跨专业自学 3D 建模、雕刻、打印与涂装。享受创作、设计与制作，独立完成原创文创、定制盲盒及游戏动漫道具，注重造型还原、设计优化与可制作性。",
    publicFacts: [
      { label: "内容平台", value: "B站：左右匠工｜1.4 万粉丝" },
      { label: "作品方向", value: "潮玩手办 · 道具 · 3D 打印实物" },
      { label: "制作实践", value: "3 台 FDM 打印机｜小批量制作" },
    ],
    tags: ["Blender", "FDM 3D 打印", "涂装 / 做旧", "AI 辅助建模", "作品展示运营"],
  },

  fitHighlights: [
    "以 Blender 完成网格建模、雕刻、基础渲染与贴图绘制，擅长硬表面与机械结构设计，持续积累角色造型实践。",
    "从原画优化、拆件设计到打印、打磨与装配，已完成定制盲盒、原创机关盒等项目及小批量制作。",
    "掌握喷涂、笔涂、做旧、渗线等后处理工艺，能把模型推进到成品展示阶段。",
    "结合 AI 参考、粗模与 Blender 手工精修；使用 Codex / OpenCode 辅助工作流，持续学习与开发 Blender 几何节点。",
  ],

  skills: [
    {
      module: "手办设计能力",
      title: "建模与造型表达",
      content:
        "主要使用 Blender 进行网格建模、雕刻、基础渲染与贴图绘制，侧重硬表面及机械结构。具备医学课程中的人体结构基础，持续练习角色雕刻；可按岗位需要学习 ZBrush。",
    },
    {
      module: "实物落地",
      title: "打印、拆件、装配",
      content:
        "拥有 3 台 FDM 打印机，可完成拆件、打印、打磨、精修与装配；光固化主要采用代打。制作范围从手办摆件到大型道具，部分作品已小批量制作。",
    },
    {
      module: "模型后处理",
      title: "涂装与成品完成度",
      content:
        "喷涂、笔涂、遮盖、做旧、渗线、简单电路焊接与模型加灯，重视最终摄影展示效果。",
    },
    {
      module: "AI 辅助 3D 工作流",
      title: "快速构思到 Blender 精修",
      content:
        "GPT 图生参考，Tripo / Hi3D 生成粗模，再用 Blender 精修。使用 Codex、OpenCode 辅助工作，已配置 Blender 建模与几何节点工具链，并持续学习开发。",
    },
  ],

  workflow: ["构思 / 参考", "Blender 建模", "拆件 / 打印", "打磨 / 精修", "涂装 / 做旧", "摄影 / 展示"],

  projects: [
    {
      id: "matt",
      title: "原创角色 Matt · 泡泡魔法",
      type: "原创角色｜潮玩概念｜Blender 场景",
      summary: "为泡泡玛特求职创作的角色概念：热爱创造的小男孩 Matt，用神奇泡泡赋予角色生命与故事。围绕角色三视图、工具口袋与扳手等标志性元素，延伸出创作工坊场景。",
      tools: "角色设定 / Blender 建模与场景表现",
      period: "概念与建模展示，设定持续完善",
      highlight: "个人原创提案，非官方合作项目；当前展示概念图与数字场景，不作为实物成品展示。",
      images: [
        { label: "角色设定与三视图", src: "assets/portfolio/matt/character-concept.png" },
        { label: "Blender 场景建模预览", src: "assets/portfolio/matt/blender-scene.png" },
        { label: "场景细节 · 角色陈列", src: "assets/portfolio/matt/character-shelf.png" },
        { label: "场景细节 · 创作工作台", src: "assets/portfolio/matt/workbench.png" },
      ],
    },
    {
      id: "aero-blindbox",
      title: "中国航发“发仔盲盒”摆件",
      type: "文创摆件｜盲盒系列｜批量制作",
      summary:
        "根据提供的原画进行优化，设计 6 种主题姿势，完成 3D 建模、结构拆件、打印与组装。所有分色均采用分件设计，无需多色打印，组装即可形成成品。",
      tools: "Blender / FDM 3D 打印 / 打磨装配",
      period: "批量制作项目",
      highlight: "所有分色按分件思路设计，体现可打印、可装配、可复制的实物落地能力。",
      images: [
        { label: "建模预览", src: "assets/portfolio/aero-blindbox/model.jpg" },
        { label: "制作过程", src: "assets/portfolio/aero-blindbox/process.jpg" },
        { label: "结构原型", src: "assets/portfolio/aero-blindbox/IMG_20240907_181159.jpg" },
        { label: "批量成品", src: "assets/portfolio/aero-blindbox/IMG_20240913_093134.jpg" },
        { label: "成品展示", src: "assets/portfolio/aero-blindbox/final.jpg" },
        { label: "细节特写", src: "assets/portfolio/aero-blindbox/detail.jpg" },
      ],
    },
    {
      id: "dishonored2",
      title: "《耻辱2》折叠刀 + 面具",
      type: "游戏道具｜复杂机械结构｜可变形",
      summary:
        "个人耗时最长、迭代版本最多的结构道具项目之一，围绕折叠机构、握持比例、零件强度和最终道具质感反复验证。",
      tools: "Blender / FDM 3D 打印 / 装配 / 涂装",
      period: "多轮迭代制作",
      highlight: "通过多轮机械结构迭代还原游戏中的折叠变形效果，也是个人 B站制作视频的主要内容之一。",
      images: [
        { label: "建模与结构", src: "assets/portfolio/dishonored2/model.jpg" },
        { label: "零件拆解", src: "assets/portfolio/dishonored2/5dc54e4093c2809b1ef57a0dae8c320c.jpg" },
        { label: "打印制作", src: "assets/portfolio/dishonored2/process.jpg" },
        { label: "制作合集", src: "assets/portfolio/dishonored2/IMG_20230816_160612_1.jpg" },
        { label: "成品展示", src: "assets/portfolio/dishonored2/final.jpg" },
        { label: "细节质感", src: "assets/portfolio/dishonored2/detail.jpg" },
        { label: "面具补充", src: "assets/portfolio/dishonored2/mask.jpg" },
        { label: "道具组合", src: "assets/portfolio/dishonored2/b0725e44-ef01-4cf1-b65d-b439b12b07f4.png" },
      ],
    },
    {
      id: "black-myth",
      title: "《黑神话：悟空》金箍棒 + 靡道人面具",
      type: "游戏道具｜1:1 大型武器｜涂装展示",
      summary:
        "从游戏预告画面开始考究纹样与比例，进行手工数字雕刻，制作 1:1 实物道具。结合喷涂、笔涂与做旧，呈现金箍棒和靡道人面具的材质细节。",
      tools: "Blender / 3D 雕刻 / 3D 打印 / 涂装",
      period: "道具制作项目",
      highlight: "以纹样雕刻与造型还原为基础，通过泥渍、阴影和做旧表现完成表面处理。",
      images: [
        { label: "建模 / 参考", src: "assets/portfolio/black-myth/model.jpg" },
        { label: "建模细节", src: "assets/portfolio/black-myth/mmexport1697214490974.png" },
        { label: "制作过程", src: "assets/portfolio/black-myth/process.jpg" },
        { label: "成品展示", src: "assets/portfolio/black-myth/final.jpg" },
        { label: "金箍棒细节", src: "assets/portfolio/black-myth/IMG_20241002_210341.jpg" },
        { label: "细节特写", src: "assets/portfolio/black-myth/detail.jpg" },
        { label: "面具补充", src: "assets/portfolio/black-myth/mask.jpg" },
      ],
    },
    {
      id: "linglong-series",
      title: "《灵笼》马克 / 律教士 / 麦朵长枪系列",
      type: "动画道具｜面具与 1:1 武器｜系列化制作",
      summary:
        "围绕《灵笼》角色和武器进行系列化制作，包含马克面具、律教士面具与麦朵六合大枪，覆盖雕刻、结构拆分、打印、打磨、上色和佩戴展示。",
      tools: "Blender / 3D 打印 / 打磨 / 涂装 / 佩戴验证",
      period: "系列化持续制作",
      highlight: "六合大枪曾于《灵笼》官方线下主题展展出；马克可穿戴外骨骼正在建模设计中，尚非完成品。",
      images: [
        { label: "马克雕刻", src: "assets/portfolio/linglong-series/mark-sculpt.jpg" },
        { label: "马克外骨骼建模 · 进行中", src: "assets/portfolio/linglong-series/mark-exoskeleton.png" },
        { label: "马克面具制作", src: "assets/portfolio/linglong-series/mark-mask.jpg" },
        { label: "马克佩戴展示", src: "assets/portfolio/linglong-series/mark-wear.jpg" },
        { label: "律教士建模", src: "assets/portfolio/linglong-series/priest-model.jpg" },
        { label: "律教士成品", src: "assets/portfolio/linglong-series/priest-final.jpg" },
        { label: "长枪建模", src: "assets/portfolio/linglong-series/gun-model.jpg" },
        { label: "长枪制作过程", src: "assets/portfolio/linglong-series/gun-process.jpg" },
        { label: "长枪成品展示", src: "assets/portfolio/linglong-series/gun-final.jpg" },
        { label: "长枪细节", src: "assets/portfolio/linglong-series/gun-detail.jpg" },
      ],
    },
    {
      id: "pku-cultural",
      title: "原创北京大学文创：众枢机关盒 + 小熊摆件",
      type: "原创文创｜机关结构｜校园周边",
      summary:
        "围绕北京大学视觉元素进行原创文创设计，包含旋转联动机关盒和小熊摆件，强调原创造型、机械开合结构与可打印拆件。",
      tools: "Blender / FDM 3D 打印 / 结构设计 / 装配",
      period: "原创设计项目",
      highlight: "旋转底座时，三瓣外壳联动打开，内部北大图书馆微缩模型螺旋上升。",
      images: [
        { label: "概念草图", src: "assets/portfolio/pku-cultural/concept.jpg" },
        { label: "建模预览", src: "assets/portfolio/pku-cultural/model.jpg" },
        { label: "结构方案", src: "assets/portfolio/pku-cultural/d1ab0329-b718-4b81-b515-c5795ce61085.png" },
        { label: "打印与零件", src: "assets/portfolio/pku-cultural/process.jpg" },
        { label: "试装零件", src: "assets/portfolio/pku-cultural/845981b5b429c5046ed233861b5d4cc8.jpg" },
        { label: "机关盒成品", src: "assets/portfolio/pku-cultural/box-final.jpg" },
        { label: "机关盒打开", src: "assets/portfolio/pku-cultural/box-open.jpg" },
        { label: "小熊摆件", src: "assets/portfolio/pku-cultural/bear-final.jpg" },
        { label: "小熊细节", src: "assets/portfolio/pku-cultural/bear-detail.jpg" },
      ],
    },
    {
      id: "yone-mask",
      title: "《英雄联盟》永恩面具",
      type: "游戏面具｜建模制作｜灯效展示",
      summary:
        "从角色面具建模到实体制作和佩戴展示，重点体现面具轮廓、曲面造型、涂装质感与发光效果。",
      tools: "Blender / 3D 打印 / 涂装 / 灯效",
      period: "其他作品速览",
      highlight: "完成面具建模、实物制作和佩戴测试，并通过简单电路实现灯效。",
      images: [
        { label: "建模预览", src: "assets/portfolio/yone-mask/model.jpg" },
        { label: "正面渲染", src: "assets/portfolio/yone-mask/render-front.jpg" },
        { label: "佩戴测试", src: "assets/portfolio/yone-mask/wear.jpg" },
        { label: "成品展示", src: "assets/portfolio/yone-mask/final.jpg" },
        { label: "灯效展示", src: "assets/portfolio/yone-mask/light.jpg" },
        { label: "亮灯对比", src: "assets/portfolio/yone-mask/comparison.jpg" },
      ],
    },
    {
      id: "carrot-knife",
      title: "原创三段式萝卜刀",
      type: "原创玩具结构｜建模制作",
      summary:
        "小型原创结构玩具项目，从三段式结构建模到打印与装配，进行实物测试和手持演示。",
      tools: "Blender / FDM 3D 打印 / 结构验证",
      period: "其他作品速览",
      highlight: "围绕三段式结构玩法完成建模与实物验证。",
      images: [
        { label: "建模截图", src: "assets/portfolio/carrot-knife/model.jpg" },
        { label: "成品展示", src: "assets/portfolio/carrot-knife/final.jpg" },
        { label: "手持演示", src: "assets/portfolio/carrot-knife/demo.jpg" },
      ],
    },
    {
      id: "folding-axe",
      title: "AI 辅助原创折叠斧刃",
      type: "原创武器道具｜AI 辅助｜折叠结构",
      summary:
        "以 AI 辅助获得方向参考，再进入 Blender 精修结构和比例，最终完成可打印、可装配、可展示的折叠斧刃道具。",
      tools: "AI 参考 / Blender / FDM 3D 打印 / 涂装",
      period: "其他作品速览",
      highlight: "用 AI 辅助探索外形方向，由人工完成结构设计、建模调整与制作。",
      images: [
        { label: "AI 方向参考", src: "assets/portfolio/folding-axe/ai-reference.jpg" },
        { label: "建模预览", src: "assets/portfolio/folding-axe/model.jpg" },
        { label: "结构细节", src: "assets/portfolio/folding-axe/model-detail.jpg" },
        { label: "早期原型", src: "assets/portfolio/folding-axe/prototype.jpg" },
        { label: "制作过程", src: "assets/portfolio/folding-axe/process.jpg" },
        { label: "成品展示", src: "assets/portfolio/folding-axe/final.jpg" },
        { label: "最终摄影", src: "assets/portfolio/folding-axe/hero.jpg" },
        { label: "涂装细节", src: "assets/portfolio/folding-axe/detail.jpg" },
      ],
    },
    {
      id: "iron-man",
      title: "漫威钢铁侠模型手办",
      type: "模型手办｜涂装作品｜灯效展示",
      summary:
        "钢铁侠模型手办涂装作品，展示表面处理、金属色涂装、灯效与最终陈列。本项目主要呈现个人涂装与制作实践。",
      tools: "模型后处理 / 涂装 / 灯效",
      period: "其他作品速览",
      highlight: "注重装甲分色、金属质感和模型灯效的整体表现。",
      images: [
        { label: "涂装过程", src: "assets/portfolio/iron-man/painting.jpg" },
        { label: "灯效展示", src: "assets/portfolio/iron-man/lighting.jpg" },
        { label: "成品展示", src: "assets/portfolio/iron-man/final.jpg" },
        { label: "全身实体展示", src: "assets/portfolio/iron-man/IMG_20250309_223338_edit_1100715654433604.jpg" },
        { label: "陈列展示", src: "assets/portfolio/iron-man/showcase.jpg" },
      ],
    },
    {
      id: "master-chief",
      title: "《光环》士官长头盔",
      type: "游戏头盔｜打印涂装｜佩戴展示",
      summary:
        "士官长头盔的打印与涂装制作，包含灰模、佩戴测试、涂装、镜片和灯效展示。",
      tools: "FDM 3D 打印 / 打磨 / 涂装 / 灯效",
      period: "其他作品速览",
      highlight: "通过佩戴测试检查尺寸，并完成表面处理、镜片与灯光细节。",
      images: [
        { label: "灰模阶段", src: "assets/portfolio/master-chief/prototype.jpg" },
        { label: "佩戴测试", src: "assets/portfolio/master-chief/wear-gray.jpg" },
        { label: "涂装过程", src: "assets/portfolio/master-chief/painting.jpg" },
        { label: "手持成品", src: "assets/portfolio/master-chief/final-hand.jpg" },
        { label: "佩戴成品", src: "assets/portfolio/master-chief/wear-final.jpg" },
        { label: "灯效正面", src: "assets/portfolio/master-chief/light-front.jpg" },
        { label: "灯效展示", src: "assets/portfolio/master-chief/light-final.jpg" },
      ],
    },
    {
      id: "spiderman-mask",
      title: "漫威蜘蛛侠缝制面具",
      type: "纯手工缝制｜面具制作",
      summary:
        "非 3D 打印的纯手工缝制作品，补充展示材料处理、版型试错、手工耐心和最终佩戴效果。",
      tools: "布料 / 缝制 / 版型调整 / 手工装配",
      period: "其他作品速览",
      highlight: "通过缝制与版型调整，反复检查面部贴合度和佩戴效果。",
      images: [
        { label: "缝制过程", src: "assets/portfolio/spiderman-mask/sewing.jpg" },
        { label: "基础佩戴", src: "assets/portfolio/spiderman-mask/base-wear.jpg" },
        { label: "版型测试", src: "assets/portfolio/spiderman-mask/shape-test.jpg" },
        { label: "贴合测试", src: "assets/portfolio/spiderman-mask/fit-test.jpg" },
        { label: "成品佩戴", src: "assets/portfolio/spiderman-mask/final.jpg" },
        { label: "成品速览", src: "assets/portfolio/spiderman-mask/overview.jpg" },
      ],
    },
  ],
};
