const data = window.PORTFOLIO_DATA;
const images = window.IMAGE_MANIFEST || {};
const projectOrder = ["matt", "aero-blindbox", "pku-cultural", "dishonored2", "black-myth", "linglong-series", "yone-mask", "carrot-knife", "folding-axe", "iron-man", "master-chief", "spiderman-mask"];
data.projects.sort((a, b) => projectOrder.indexOf(a.id) - projectOrder.indexOf(b.id));

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

function text(selector, value) {
  const el = $(selector);
  if (el) el.textContent = value;
}

function createPublicFact(item) {
  const element = document.createElement("div");
  element.className = "public-fact";
  element.innerHTML = `<span>${item.label}</span><span>${item.value}</span>`;
  return element;
}

function renderProfile() {
  text("#hero-title", data.profile.name);
  text(".hero-title", data.profile.title);
  $(".hero-title").replaceChildren(...data.profile.title.split("｜").map((part) => {
    const span = document.createElement("span");
    span.textContent = part;
    return span;
  }));
  text(".hero-summary", data.profile.summary);
  const slogan = $('[data-render="slogan"]');
  slogan.replaceChildren(
    ...data.profile.slogan.split(" · ").map((item) => {
      const line = document.createElement("span");
      line.className = "slogan-line";
      line.textContent = item;
      return line;
    }),
  );
  text('[data-render="school"]', data.profile.school);
  text('[data-render="location"]', `所在地：${data.profile.location}`);
  text('[data-render="recruitment"]', data.profile.recruitment);
  text('[data-render="year"]', new Date().getFullYear());

  const tags = $('[data-render="tags"]');
  tags.replaceChildren(
    ...data.profile.tags.map((tag) => {
      const el = document.createElement("span");
      el.className = "tag";
      el.textContent = tag;
      return el;
    }),
  );

  const publicFacts = $('[data-render="publicFacts"]');
  publicFacts.replaceChildren(...data.profile.publicFacts.map(createPublicFact));

  const cover = images["assets/cover-background.png"];
  const hero = $(".hero-art img");
  if (cover) {
    hero.sizes = "(max-width: 960px) 100vw, 760px";
    hero.srcset = `${cover.small.src} ${cover.small.width}w, ${cover.medium.src} ${cover.medium.width}w`;
    hero.width = cover.width;
    hero.height = cover.height;
    hero.src = cover.medium.src;
  } else hero.src = "assets/cover-background.png";
}

function renderFit() {
  const fit = $('[data-render="fit"]');
  fit.replaceChildren(
    ...data.fitHighlights.map((item) => {
      const el = document.createElement("div");
      el.className = "highlight-item";
      el.textContent = item;
      return el;
    }),
  );
}

function renderSkills() {
  const grid = $('[data-render="skills"]');
  grid.replaceChildren(
    ...data.skills.map((skill) => {
      const card = document.createElement("article");
      card.className = "skill-card";
      card.innerHTML = `
        <span class="module">${skill.module}</span>
        <h3>${skill.title}</h3>
        <p>${skill.content}</p>
      `;
      return card;
    }),
  );
}

function renderWorkflow() {
  const track = $('[data-render="workflow"]');
  track.replaceChildren(
    ...data.workflow.map((item, index) => {
      const el = document.createElement("div");
      el.className = "workflow-step";
      el.innerHTML = `<b>${String(index + 1).padStart(2, "0")}</b><span>${item}</span>`;
      return el;
    }),
  );
}

function renderProjects() {
  const browser = $('[data-render="projects"]');
  browser.innerHTML = `
    <div class="project-picker"><label for="project-select">选择作品</label><select id="project-select"></select></div>
    <aside class="project-list" aria-label="作品列表"></aside>
    <article class="project-detail" aria-live="polite"></article>
  `;

  const list = $(".project-list", browser);
  const detail = $(".project-detail", browser);
  const select = $("#project-select", browser);
  data.projects.forEach((project, index) => select.add(new Option(`${String(index + 1).padStart(2, "0")} · ${project.title}`, index)));
  select.addEventListener("change", () => setActiveProject(Number(select.value), list, detail, { scrollToStart: true }));

  list.replaceChildren(
    ...data.projects.map((project, index) => {
      const button = document.createElement("button");
      button.className = "project-nav-item";
      button.type = "button";
      button.dataset.index = index;
      button.innerHTML = `
        <span>${String(index + 1).padStart(2, "0")}</span>
        <strong>${project.title}</strong>
        <em>${project.type}</em>
      `;
      button.addEventListener("click", () =>
        setActiveProject(index, list, detail, { scrollToStart: true }),
      );
      return button;
    }),
  );

  setActiveProject(0, list, detail);
}

function setActiveProject(index, list, detail, options = {}) {
  photoObserver?.disconnect();
  $("#project-select").value = index;
  $$(".project-nav-item", list).forEach((button) => {
    const active = Number(button.dataset.index) === index;
    button.classList.toggle("is-active", active);
    button.setAttribute("aria-current", active ? "true" : "false");
  });

  const project = data.projects[index];
  detail.innerHTML = `
    <div class="project-detail-head">
      <p class="project-type">${project.type}</p>
      <h3>${project.title}</h3>
      <details class="project-description" ${matchMedia("(min-width: 961px) and (min-height: 800px)").matches ? "open" : ""}>
      <summary>项目简介与制作信息</summary>
      <p>${project.summary}</p>
      <div class="project-meta">
        <span>工具：${project.tools}</span>
        <span>状态：${project.period}</span>
        <span>${project.highlight}</span>
      </div>
      </details>
      <p class="project-image-count">${project.images.length} 张图片 · 点击图片查看大图</p>
    </div>
    <div class="project-photo-scroll" tabindex="0" aria-label="${project.title}图片滚动区域">
      ${project.images
        .map(
          (image) => `
            <figure class="project-photo">
              <button type="button" data-image="${image.src}" data-caption="${project.title}｜${image.label}">
                ${photoMarkup(image, project.title)}
              </button>
              <figcaption>${image.label}</figcaption>
            </figure>
          `,
        )
        .join("")}
    </div>
  `;

  $$("img[data-src]", detail).forEach((image) => {
    if (photoObserver) photoObserver.observe(image);
    else loadPhoto(image);
  });

  $$("[data-image]", detail).forEach((button) => {
    button.addEventListener("click", () => openLightbox(button.dataset.image, button.dataset.caption));
  });

  if (options.scrollToStart) {
    // New project content may be shorter than the preceding one. Reset both
    // possible scroll containers after it has been rendered, then anchor the
    // page to this project's heading rather than retaining the old position.
    const resetProjectView = () => {
      const photoScroll = $(".project-photo-scroll", detail);
      if (photoScroll) {
        photoScroll.scrollTop = 0;
        photoScroll.scrollLeft = 0;
      }

      const stickyOffset = matchMedia("(max-width: 960px)").matches ? 142 : matchMedia("(max-width: 1439px)").matches ? 94 : 24;
      const detailTop = window.scrollY + detail.getBoundingClientRect().top;
      window.scrollTo({ top: Math.max(0, detailTop - stickyOffset), behavior: "instant" });
    };

    requestAnimationFrame(() => {
      resetProjectView();
      requestAnimationFrame(resetProjectView);
    });
  }
}

function photoMarkup(image, title) {
  const version = images[image.src];
  if (!version) return `<img data-src="${image.src}" alt="${title}｜${image.label}" loading="lazy" decoding="async">`;
  const variants = version.small.width === version.medium.width ? `${version.medium.src} ${version.medium.width}w` : `${version.small.src} ${version.small.width}w, ${version.medium.src} ${version.medium.width}w`;
  return `<img data-src="${version.medium.src}" data-srcset="${variants}" sizes="(max-width: 680px) calc(100vw - 64px), (max-width: 960px) calc(100vw - 96px), 760px" width="${version.width}" height="${version.height}" alt="${title}｜${image.label}" decoding="async">`;
}

function loadPhoto(image) {
  image.addEventListener("load", () => image.classList.add("is-loaded"), { once: true });
  image.addEventListener("error", () => {
    image.classList.add("is-loaded");
    image.alt += "（图片暂未加载，请点击重试预览）";
  }, { once: true });
  if (image.dataset.srcset) image.srcset = image.dataset.srcset;
  image.src = image.dataset.src;
  image.removeAttribute("data-src");
}

// A bounded prefetch distance avoids downloading an entire project on entry.
const photoObserver = "IntersectionObserver" in window ? new IntersectionObserver((entries) => {
  entries.forEach(({ target, isIntersecting }) => {
    if (!isIntersecting) return;
    loadPhoto(target);
    photoObserver.unobserve(target);
  });
}, { rootMargin: "400px 0px" }) : null;

let lightboxTrigger;
function openLightbox(src, caption) {
  const lightbox = $(".lightbox");
  const image = $("img", lightbox);
  const textNode = $("p", lightbox);
  lightboxTrigger = document.activeElement;
  image.src = images[src]?.large.src || src;
  image.alt = caption;
  textNode.textContent = caption;
  lightbox.hidden = false;
  document.body.classList.add("lightbox-open");
  $(".lightbox-close").focus();
}

function closeLightbox() {
  $(".lightbox").hidden = true;
  document.body.classList.remove("lightbox-open");
  lightboxTrigger?.focus({ preventScroll: true });
}

function bindLightbox() {
  $(".lightbox-close").addEventListener("click", closeLightbox);
  $(".lightbox").addEventListener("click", (event) => {
    if (event.target.classList.contains("lightbox")) closeLightbox();
  });
  window.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeLightbox();
    if (event.key === "Tab" && !$(".lightbox").hidden) {
      event.preventDefault();
      $(".lightbox-close").focus();
    }
  });
}

renderProfile();
renderFit();
renderSkills();
renderWorkflow();
renderProjects();
bindLightbox();

matchMedia("(min-width: 961px) and (min-height: 800px)").addEventListener("change", (event) => {
  const description = $(".project-description");
  if (description) description.open = event.matches;
});
